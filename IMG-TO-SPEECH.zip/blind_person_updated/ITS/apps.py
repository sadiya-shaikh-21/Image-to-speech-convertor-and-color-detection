from django.apps import AppConfig


class ItsConfig(AppConfig):
    name = 'ITS'
