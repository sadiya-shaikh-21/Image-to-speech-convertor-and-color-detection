from django.shortcuts import render
from django.http import HttpResponse,JsonResponse #JsonResponse has also been imported
import json # json module has also been imported

import os #new import

# Create your views here.
def home(request):
  return render(request, 'home.html')

def recieveDataForModel(request):

  # json.loads will parse the stringified JSON Data we sent from ajax via request body(frontend)

  received_data = json.loads(request.body)
  
  if received_data == 'color-detection':
    os.system("start cmd /k python ./color_D.py")
  elif received_data == 'img-to-speech':
     os.system("start cmd /k python ./img-to-speech.py")
    # notice the project structure to give the right path,
    # here I have considered color_D.py to be in same directory as manage.py
    # don't forget to remove pass when os.system is added
  elif received_data == 'cap-img':
     os.system("start cmd /k python ./cap-img.py")
  else:
    print('nothing found')

  # give any message here..send any data here if needed..add another key-value pair in dictionary
  myRes= {
    'message': 'Success'
  }

  # here we return a Json response 
  return JsonResponse(myRes)


